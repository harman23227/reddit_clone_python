export const environment = {
  production: true,
  baseUrl: '/api/v1/',
  serverUrl: 'https://django-reddit.onrender.com',
  appUrl: 'https://madhvi-n.github.io/django_reddit',
  loginUrl: 'https://madhvi-n.github.io/django_reddit/sign-in',
  staticUrl: '../assets/images/'
};
