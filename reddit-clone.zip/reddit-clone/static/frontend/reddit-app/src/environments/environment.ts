export const environment = {
  production: false,
  baseUrl: '/api/v1/',
  serverUrl: 'http://localhost:8000',
  appUrl: 'http://localhost:4200',
  loginUrl: 'http://localhost:4200/sign-in',
  staticUrl: '../assets/images/'
};
