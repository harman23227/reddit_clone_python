export class Report {
  id: number;
  user: number;
}
