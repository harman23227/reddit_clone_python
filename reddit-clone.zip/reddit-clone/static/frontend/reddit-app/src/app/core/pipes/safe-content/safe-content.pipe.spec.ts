import { SafeContentPipe } from './safe-content.pipe';

describe('SafeContentPipe', () => {
  it('create an instance', () => {
    const pipe = new SafeContentPipe();
    expect(pipe).toBeTruthy();
  });
});
