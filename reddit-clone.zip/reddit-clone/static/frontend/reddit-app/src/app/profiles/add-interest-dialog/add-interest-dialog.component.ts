import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-interest-dialog',
  templateUrl: './add-interest-dialog.component.html',
  styleUrls: ['./add-interest-dialog.component.scss']
})
export class AddInterestDialogComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
