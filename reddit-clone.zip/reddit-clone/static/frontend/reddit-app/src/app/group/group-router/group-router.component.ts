import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-router',
  templateUrl: './group-router.component.html',
  styleUrls: ['./group-router.component.scss']
})
export class GroupRouterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
