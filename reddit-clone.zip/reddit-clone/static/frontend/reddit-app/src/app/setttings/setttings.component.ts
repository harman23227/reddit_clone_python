import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setttings',
  templateUrl: './setttings.component.html',
  styleUrls: ['./setttings.component.scss']
})
export class SetttingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
